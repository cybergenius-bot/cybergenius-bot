import os

API_TOKEN = "8211732426:AAGrJltiLocrI1jp__d_Ijkm47GTP4rlUzc"

FREE_QUESTIONS = 10  # бесплатные вопросы
PAID_PER_QUESTION = 3  # шек/вопрос
UNLIM_PRICE = 99  # шек/мес
DB_PATH = "bot.db"

CATEGORIES = ["Стройка", "Отношения", "Секс", "Бизнес", "Жизнь", "Другое"]
